// =====================================================================
//  apps.h  -  앱 목록. 새 앱을 만들면 여기에 함수 이름을 적고,
//             StudyPad.ino 의 APPS[] 표에 한 줄 추가하면 홈 화면에 나와요.
// =====================================================================
#pragma once
#include "ui.h"

void appMinesweeper();   // app_minesweeper.cpp
void appWords();         // app_words.cpp
void appQuiz();          // app_quiz.cpp
void appPaint();         // app_paint.cpp
void appMemo();          // app_paint.cpp (그림판과 같은 엔진)
void appTimer();         // app_timer.cpp
void appCalc();          // app_calc.cpp
void appRandom();        // app_random.cpp
void appSettings();      // app_settings.cpp
void appReaction();      // app_reaction.cpp  ← 새 앱 만들기 예제
