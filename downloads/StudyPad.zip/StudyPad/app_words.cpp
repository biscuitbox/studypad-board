// =====================================================================
//  영어 단어
//   위쪽 탭에서 단어장을 골라요: 전체 / 중학 / 고등 / 숙어
//   0) 하루 10단어 : 일차별로 10개씩 익히고 → 테스트(8개 이상 맞히면 통과)
//                    → 다음 일차로! 지난 단어는 '복습 테스트'로 다시 확인
//   1) 카드 학습   : 영어를 보고 뜻을 떠올린 뒤 카드를 톡! (몰라요 → 오답 노트)
//   2) 뜻 맞히기   : 4지선다 10문제
//   3) 철자 쓰기   : 뜻을 보고 영어 철자를 키보드로 입력
//   4) 오답 노트   : 틀린 단어만 모아서 다시 공부
//  단어는 data_words.h 에서 바꿀 수 있어요.
// =====================================================================
#include "apps.h"
#include "data_words.h"

const int WORD_MAX = 2000;                 // 넣을 수 있는 최대 단어 수
static_assert(WORD_COUNT <= WORD_MAX, "data_words.h 단어가 너무 많아요 (WORD_MAX 확인)");

namespace {

const int DAY_SIZE = 10;                   // 하루에 외울 단어 수
const int PASS_SCORE = 8;                  // 테스트 통과 점수 (10개 중)

const int COURSES = 4;
const char* const COURSE_NAMES[COURSES] = { "전체", "중학", "고등", "숙어" };
int course = 0;                            // 0 = 전체, 1~3 = WORDS[].lv

uint8_t  wrongBits[WORD_MAX / 8];          // 오답 표시 (단어 하나에 1비트)
bool     wrongDirty = false;
uint16_t pool[WORD_MAX];                   // 문제로 쓸 단어 번호 목록
uint16_t dayList[DAY_SIZE];                // 하루 10단어 / 복습용 목록

// ---------------------------------------------------------------------
//  오답 표시
// ---------------------------------------------------------------------
bool isWrong(int i) { return wrongBits[i >> 3] & (1 << (i & 7)); }
void setWrong(int i, bool on) {
  if (i < 0 || i >= WORD_MAX) return;
  if (on) wrongBits[i >> 3] |= (1 << (i & 7));
  else    wrongBits[i >> 3] &= ~(1 << (i & 7));
  wrongDirty = true;
}
void saveWrong() {
  if (!wrongDirty) return;
  kvSetBytes("w_wrong", wrongBits, sizeof(wrongBits));
  wrongDirty = false;
}

bool inCourse(int i) { return course == 0 || WORDS[i].lv == course; }

int wrongCount() {
  int n = 0;
  for (int i = 0; i < WORD_COUNT; i++) if (inCourse(i) && isWrong(i)) n++;
  return n;
}
int makePool(bool onlyWrong) {
  int n = 0;
  for (int i = 0; i < WORD_COUNT; i++) if (inCourse(i) && (!onlyWrong || isWrong(i))) pool[n++] = i;
  return n;
}

// 진도 저장 키 (단어장마다 따로)
void dayKey(char* k) { snprintf(k, 12, "w_day%d", course); }

// ---------------------------------------------------------------------
//  공통 그리기
// ---------------------------------------------------------------------
// 영어를 크게 (너무 길면 작은 글꼴로)
void drawEnglish(const char* en, int cx, int cy, uint16_t fg, uint16_t bg, int maxW = 204) {
  lcd.setFont(&fonts::FreeSansBold18pt7b);
  if (lcd.textWidth(en) > maxW) lcd.setFont(&fonts::FreeSansBold12pt7b);
  if (lcd.textWidth(en) > maxW) lcd.setFont(&fonts::FreeSansBold9pt7b);
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(fg, bg);
  lcd.drawString(en, cx, cy);
}

// 한글 뜻 (너무 길면 작은 글꼴로)
void drawMeaning(const char* ko, int cx, int cy, int w, uint16_t fg, uint16_t bg) {
  uiFont(24);
  if (lcd.textWidth(ko) > w) uiFont(16);
  int lines = uiWrap(ko, cx - w / 2, 0, w, 22, fg, bg, true, false);
  uiWrap(ko, cx - w / 2, cy - lines * 11, w, 22, fg, bg, true);
}

void drawCounter(int a, int b, uint16_t barColor) {
  char s[24];
  snprintf(s, sizeof(s), "%d / %d", a, b);
  uiFont(12);
  lcd.setTextDatum(middle_right);
  lcd.setTextColor(TFT_WHITE, barColor);
  lcd.drawString(s, 234, 17);
}

// 잠깐 기다리기 (화면을 누르면 바로 넘어감)
void waitOrTap(uint16_t ms) {
  uint32_t end = millis() + ms;
  while ((int32_t)(millis() - end) < 0) {
    Touch t = readTouch();
    if (t.type == T_UP) break;
    delay(5);
  }
}

// ---------------------------------------------------------------------
//  카드 학습 (list 의 단어를 한 장씩). 마지막 위치를 돌려줌
// ---------------------------------------------------------------------
int cards(uint16_t* list, int n, const char* title, int pos, const char* posKey = nullptr) {
  if (n <= 0) return 0;
  pos %= n;
  bool reveal = false, redraw = true;
  const Btn CARD = { 12, 42, 216, 192 };
  const Btn PREV = { 8, 242, 44, 42 }, NO = { 58, 242, 60, 42 }, YES = { 122, 242, 60, 42 }, NEXT = { 188, 242, 44, 42 };
  const Btn MIX  = { 8, 290, 224, 26 };

  while (true) {
    if (redraw) {
      redraw = false;
      int w = list[pos];
      lcd.fillScreen(C_BG);
      uiTopBar(title, C_WORD);
      drawCounter(pos + 1, n, C_WORD);
      lcd.fillRoundRect(CARD.x, CARD.y, CARD.w, CARD.h, 14, C_CARD);
      lcd.drawRoundRect(CARD.x, CARD.y, CARD.w, CARD.h, 14, C_LINE);
      if (isWrong(w)) {
        uiFont(12);
        lcd.fillRoundRect(CARD.x + 8, CARD.y + 8, 60, 18, 9, C_BAD);
        uiCenter("오답", CARD.x + 38, CARD.y + 17, TFT_WHITE, C_BAD);
      }
      drawEnglish(WORDS[w].en, 120, reveal ? 96 : 130, C_TEXT, C_CARD);
      if (reveal) {
        lcd.drawFastHLine(40, 128, 160, C_LINE);
        drawMeaning(WORDS[w].ko, 120, 180, 196, C_WORD, C_CARD);
      } else {
        uiFont(12);
        uiCenter("카드를 톡 누르면 뜻이 보여요", 120, 214, C_SUB, C_CARD);
      }
      uiButton(PREV, "◀", C_LINE, C_TEXT);
      uiButton(NO, "몰라요", C_BAD);
      uiButton(YES, "알아요", C_OK);
      uiButton(NEXT, "▶", C_LINE, C_TEXT);
      uiButton(MIX, "순서 섞기", C_BG, C_SUB, 12);
    }
    if (redraw && posKey) kvSetInt(posKey, pos);   // 보던 위치 바로 저장
    Touch t = readTouch();
    if (uiHitHome(t)) break;
    int w = list[pos];
    if (CARD.hit(t)) { reveal = !reveal; sfx(SFX_CLICK); redraw = true; }
    else if (PREV.hit(t)) { pos = (pos + n - 1) % n; reveal = false; redraw = true; sfx(SFX_CLICK); }
    else if (NEXT.hit(t)) { pos = (pos + 1) % n; reveal = false; redraw = true; sfx(SFX_CLICK); }
    else if (NO.hit(t))   { setWrong(w, true);  saveWrong(); sfx(SFX_WRONG); pos = (pos + 1) % n; reveal = false; redraw = true; }
    else if (YES.hit(t))  { setWrong(w, false); saveWrong(); sfx(SFX_OK);    pos = (pos + 1) % n; reveal = false; redraw = true; }
    else if (MIX.hit(t))  { uiShuffle16(list, n); pos = 0; reveal = false; redraw = true; uiToast("섞었어요!", C_WORD, 500); }
    delay(5);
  }
  saveWrong();
  return pos;
}

// ---------------------------------------------------------------------
//  4지선다 퀴즈 엔진. qs 의 단어들을 차례로 묻고 점수를 돌려줌 (-1 = 중간에 나감)
//  틀리면 오답 노트에 넣고, clearOnOk 이면 맞힌 단어는 오답 노트에서 빼요.
// ---------------------------------------------------------------------
int pickDistractor(int answer, const int* used, int usedN) {
  for (int tries = 0; tries < 300; tries++) {
    int c = random(WORD_COUNT);
    if (tries < 200 && WORDS[c].lv != WORDS[answer].lv) continue;   // 같은 단어장에서 고르기
    bool dup = false;
    for (int j = 0; j < usedN; j++)
      if (used[j] == c || strcmp(WORDS[used[j]].ko, WORDS[c].ko) == 0) dup = true;
    if (!dup) return c;
  }
  return (answer + 1 + usedN) % WORD_COUNT;
}

int quizRun(const uint16_t* qs, int qn, const char* title, bool clearOnOk) {
  int score = 0;
  for (int q = 0; q < qn; q++) {
    int w = qs[q];
    int ch[4] = { w, -1, -1, -1 };
    for (int k = 1; k < 4; k++) ch[k] = pickDistractor(w, ch, k);
    uint8_t order[4] = { 0, 1, 2, 3 };
    uiShuffle(order, 4);

    lcd.fillScreen(C_BG);
    uiTopBar(title, C_WORD);
    drawCounter(q + 1, qn, C_WORD);
    lcd.fillRect(0, TOPBAR_H, SCREEN_W * q / qn, 3, C_OK);
    lcd.fillRoundRect(12, 44, 216, 80, 14, C_CARD);
    drawEnglish(WORDS[w].en, 120, 84, C_TEXT, C_CARD);
    Btn b[4];
    for (int k = 0; k < 4; k++) {
      b[k] = { 12, (int16_t)(136 + k * 45), 216, 39 };
      uiChoice(b[k], WORDS[ch[order[k]]].ko, C_CARD, C_TEXT, C_LINE);
    }
    int picked = -1;
    while (picked < 0) {
      Touch t = readTouch();
      if (uiHitHome(t)) { saveWrong(); return -1; }
      for (int k = 0; k < 4; k++) if (b[k].hit(t)) picked = k;
      delay(5);
    }
    bool ok = (order[picked] == 0);
    for (int k = 0; k < 4; k++) {
      if (order[k] == 0) uiChoice(b[k], WORDS[ch[0]].ko, C_OK, TFT_WHITE, C_OK);
      else if (k == picked) uiChoice(b[k], WORDS[ch[order[k]]].ko, C_BAD, TFT_WHITE, C_BAD);
    }
    if (ok) { score++; sfx(SFX_OK); ledFlash(false, true, false, 300); if (clearOnOk) setWrong(w, false); }
    else    { sfx(SFX_WRONG); ledFlash(true, false, false, 300); setWrong(w, true); }
    saveWrong();                                   // 배터리가 갑자기 꺼져도 남도록 바로 저장
    waitOrTap(ok ? 900 : 1800);
  }
  saveWrong();
  return score;
}

bool quizMode(bool onlyWrong) {
  int n = makePool(onlyWrong);
  if (n == 0) { uiToast(onlyWrong ? "오답 노트가 비어 있어요" : "단어가 없어요", C_OK); return false; }
  uiShuffle16(pool, n);
  int qn = n < 10 ? n : 10;
  const char* title = onlyWrong ? "오답 퀴즈" : "뜻 맞히기";
  int score = quizRun(pool, qn, title, onlyWrong);
  if (score < 0) return false;
  return uiResult(title, C_WORD, score, qn);
}

// ---------------------------------------------------------------------
//  철자 쓰기
// ---------------------------------------------------------------------
bool spellable(const char* s) {
  int n = 0;
  for (; *s; s++, n++) if (*s < 'a' || *s > 'z') return false;
  return n > 0 && n <= 12;
}

const char* ROW1 = "qwertyuiop";
const char* ROW2 = "asdfghjkl";
const char* ROW3 = "zxcvbnm";

void drawKey(int x, int y, int w, const char* label, uint16_t bg, uint16_t fg) {
  lcd.fillRoundRect(x + 1, y + 1, w - 2, 36, 5, bg);
  lcd.setFont(&fonts::FreeSans9pt7b);
  if ((uint8_t)label[0] >= 0x80) uiFont(12);
  uiCenter(label, x + w / 2, y + 19, fg, bg);
}

void drawKeyboard() {
  lcd.fillRect(0, 196, SCREEN_W, 124, UI_RGB(214, 219, 228));
  char k[2] = { 0, 0 };
  for (int i = 0; i < 10; i++) { k[0] = ROW1[i]; drawKey(i * 24, 198, 24, k, C_CARD, C_TEXT); }
  for (int i = 0; i < 9; i++)  { k[0] = ROW2[i]; drawKey(12 + i * 24, 238, 24, k, C_CARD, C_TEXT); }
  drawKey(0, 278, 36, "←", C_SUB, TFT_WHITE);
  for (int i = 0; i < 7; i++)  { k[0] = ROW3[i]; drawKey(36 + i * 24, 278, 24, k, C_CARD, C_TEXT); }
  drawKey(204, 278, 36, "확인", C_WORD, TFT_WHITE);
}

// 누른 키: 글자, 8 = 지우기, 13 = 확인, 0 = 없음
char keyAt(int x, int y) {
  if (y >= 198 && y < 238) { int i = x / 24; if (i >= 0 && i < 10) return ROW1[i]; }
  if (y >= 238 && y < 278) { int i = (x - 12) / 24; if (x >= 12 && i < 9) return ROW2[i]; }
  if (y >= 278 && y < 320) {
    if (x < 36) return 8;
    if (x >= 204) return 13;
    int i = (x - 36) / 24; if (i >= 0 && i < 7) return ROW3[i];
  }
  return 0;
}

void drawSlots(const char* word, const char* typed, uint16_t color) {
  int len = strlen(word);
  int sw = len > 0 ? 216 / len : 18;
  if (sw > 22) sw = 22;
  int x0 = 120 - sw * len / 2;
  lcd.fillRect(0, 100, SCREEN_W, 40, C_BG);
  lcd.setFont(&fonts::FreeSansBold12pt7b);
  lcd.setTextDatum(bottom_center);
  for (int i = 0; i < len; i++) {
    int x = x0 + i * sw;
    lcd.drawFastHLine(x + 2, 134, sw - 4, C_SUB);
    if (typed[i]) {
      char c[2] = { typed[i], 0 };
      lcd.setTextColor(color, C_BG);
      lcd.drawString(c, x + sw / 2, 132);
    }
  }
}

bool spelling() {
  int n = 0;
  for (int i = 0; i < WORD_COUNT; i++) if (inCourse(i) && spellable(WORDS[i].en)) pool[n++] = i;
  if (n == 0) { uiToast("철자 쓰기는 한 단어만 나와요", C_BAD); return false; }
  uiShuffle16(pool, n);
  int qn = n < 10 ? n : 10, score = 0;
  const Btn HINT = { 12, 150, 104, 34 }, GIVEUP = { 124, 150, 104, 34 };

  for (int q = 0; q < qn; q++) {
    int w = pool[q];
    const char* word = WORDS[w].en;
    int len = strlen(word);
    char typed[16] = { 0 };
    int tl = 0;
    bool hinted = false;

    lcd.fillScreen(C_BG);
    uiTopBar("철자 쓰기", C_WORD);
    drawCounter(q + 1, qn, C_WORD);
    lcd.fillRoundRect(12, 40, 216, 54, 12, C_CARD);
    drawMeaning(WORDS[w].ko, 120, 67, 200, C_WORD, C_CARD);
    drawSlots(word, typed, C_TEXT);
    uiButton(HINT, "힌트", C_WARN);
    uiButton(GIVEUP, "모르겠어요", C_SUB);
    drawKeyboard();

    int result = 0;   // 1 = 정답, -1 = 오답
    while (!result) {
      Touch t = readTouch();
      if (uiHitHome(t)) { saveWrong(); return false; }
      if (HINT.hit(t)) {
        // 앞에서부터 맞는 글자까지 남기고 다음 글자 하나 알려주기
        int k = 0;
        while (k < tl && typed[k] == word[k]) k++;
        if (k < len) { typed[k] = word[k]; tl = k + 1; typed[tl] = 0; hinted = true; }
        drawSlots(word, typed, C_TEXT);
        sfx(SFX_CLICK);
        if (tl == len) result = 1;
        continue;
      }
      if (GIVEUP.hit(t)) { result = -1; break; }
      if (t.type == T_UP && !t.longed && t.y >= 196) {
        char k = keyAt(t.x, t.y);
        if (!k) continue;
        sfx(SFX_TICK);
        if (k == 8) { if (tl > 0) typed[--tl] = 0; }
        else if (k == 13) { if (tl > 0) result = (strcmp(typed, word) == 0) ? 1 : -1; }
        else if (tl < len) { typed[tl++] = k; typed[tl] = 0; }
        drawSlots(word, typed, C_TEXT);
        if (tl == len && strcmp(typed, word) == 0) result = 1;
      }
      delay(3);
    }
    lcd.fillRect(0, 144, SCREEN_W, 46, C_BG);
    uiFont(16);
    if (result == 1) {
      drawSlots(word, word, C_OK);
      if (!hinted) score++;
      uiCenter(hinted ? "정답! (힌트 사용)" : "정답!", 120, 166, C_OK, C_BG);
      sfx(SFX_OK); ledFlash(false, true, false, 300);
      setWrong(w, hinted);
      saveWrong();
      waitOrTap(1000);
    } else {
      drawSlots(word, word, C_BAD);
      uiCenter("정답을 확인해요", 120, 166, C_BAD, C_BG);
      sfx(SFX_WRONG); ledFlash(true, false, false, 300);
      setWrong(w, true);
      saveWrong();
      waitOrTap(2200);
    }
  }
  saveWrong();
  return uiResult("철자 쓰기", C_WORD, score, qn);
}

// ---------------------------------------------------------------------
//  오답 노트
// ---------------------------------------------------------------------
void wrongNote() {
  const int PER = 6;
  int page = 0;
  bool redraw = true;
  const Btn PREV = { 8, 250, 50, 28 }, NEXT = { 182, 250, 50, 28 };
  const Btn CARD = { 8, 284, 72, 32 }, QUIZ = { 84, 284, 72, 32 }, CLEAR = { 160, 284, 72, 32 };
  while (true) {
    int n = makePool(true);
    int pages = n ? (n + PER - 1) / PER : 1;
    if (page >= pages) page = pages - 1;
    if (redraw) {
      redraw = false;
      lcd.fillScreen(C_BG);
      char s[40];
      snprintf(s, sizeof(s), "오답 노트 · %s", COURSE_NAMES[course]);
      uiTopBar(s, C_WORD);
      if (n == 0) {
        uiFont(16);
        uiCenter("틀린 단어가 없어요!", 120, 140, C_OK, C_BG);
      }
      for (int i = 0; i < PER && page * PER + i < n; i++) {
        int w = pool[page * PER + i];
        int y = 38 + i * 35;
        lcd.fillRoundRect(8, y, 224, 32, 6, C_CARD);
        lcd.setFont(&fonts::FreeSansBold9pt7b);
        lcd.setTextDatum(middle_left);
        lcd.setTextColor(C_TEXT, C_CARD);
        lcd.drawString(WORDS[w].en, 14, y + 9);
        uiFont(12);
        lcd.setTextColor(C_WORD, C_CARD);
        lcd.drawString(WORDS[w].ko, 14, y + 24);
      }
      snprintf(s, sizeof(s), "%d / %d 쪽", page + 1, pages);
      uiFont(12);
      uiCenter(s, 120, 264, C_SUB, C_BG);
      uiButton(PREV, "◀", C_LINE, C_TEXT);
      uiButton(NEXT, "▶", C_LINE, C_TEXT);
      uiButton(CARD, "카드", C_WORD);
      uiButton(QUIZ, "퀴즈", C_OK);
      uiButton(CLEAR, "비우기", C_BAD);
    }
    Touch t = readTouch();
    if (uiHitHome(t)) return;
    if (PREV.hit(t) && page > 0) { page--; redraw = true; sfx(SFX_CLICK); }
    if (NEXT.hit(t) && page < pages - 1) { page++; redraw = true; sfx(SFX_CLICK); }
    if (CARD.hit(t)) {
      sfx(SFX_CLICK);
      if (n) cards(pool, n, "오답 카드", 0); else uiToast("오답 노트가 비어 있어요", C_OK);
      redraw = true;
    }
    if (QUIZ.hit(t)) { sfx(SFX_CLICK); while (quizMode(true)) {} redraw = true; }
    if (CLEAR.hit(t)) {
      if (uiConfirm("이 단어장의 오답 노트를 모두 지울까요?")) {
        for (int i = 0; i < WORD_COUNT; i++) if (inCourse(i)) setWrong(i, false);
        saveWrong();
      }
      redraw = true;
    }
    delay(5);
  }
}

// ---------------------------------------------------------------------
//  하루 10단어
//   - 단어장의 단어를 파일 순서대로 10개씩 묶어 1일차, 2일차 ... 로 나눠요.
//   - 익히기(카드) → 테스트(8개 이상 맞히면 통과) → 다음 일차가 열려요.
//   - 복습 테스트: 이미 통과한 일차의 단어 중 틀렸던 것부터 10개.
// ---------------------------------------------------------------------
int dayWords(int day, int n) {            // pool 에 단어장 순서가 들어 있어야 함
  int cnt = 0;
  for (int i = day * DAY_SIZE; i < n && cnt < DAY_SIZE; i++) dayList[cnt++] = pool[i];
  return cnt;
}

// 테스트 결과 화면 (확인 버튼만)
void dayResult(int score, int total, bool passed, bool newlyPassed, int nextDay, bool allDone) {
  lcd.fillScreen(C_BG);
  uiTopBar("테스트 결과", C_WORD);
  lcd.fillRoundRect(20, 50, 200, 190, 16, C_CARD);
  char s[64];
  snprintf(s, sizeof(s), "%d / %d", score, total);
  lcd.setFont(&fonts::FreeSansBold24pt7b);
  uiCenter(s, 120, 100, C_TEXT, C_CARD);
  uiFont(24);
  uiCenter(passed ? "통과!" : "아쉬워요", 120, 148, passed ? C_OK : C_BAD, C_CARD);
  uiFont(16);
  if (!passed) {
    snprintf(s, sizeof(s), "%d개 이상 맞히면 통과예요", PASS_SCORE * total / DAY_SIZE);
    uiCenter(s, 120, 184, C_TEXT, C_CARD);
    uiCenter("틀린 단어를 다시 익혀 봐요", 120, 208, C_SUB, C_CARD);
  } else if (allDone) {
    uiCenter("이 단어장을 다 끝냈어요!", 120, 184, C_TEXT, C_CARD);
    uiCenter("복습 테스트로 다져요", 120, 208, C_SUB, C_CARD);
  } else if (newlyPassed) {
    snprintf(s, sizeof(s), "다음은 %d일차예요", nextDay + 1);
    uiCenter(s, 120, 184, C_TEXT, C_CARD);
    uiCenter("내일 또 만나요!", 120, 208, C_SUB, C_CARD);
  } else {
    uiCenter("이미 통과한 일차예요", 120, 184, C_TEXT, C_CARD);
  }
  if (passed) { sfx(SFX_WIN); ledFlash(false, true, false, 1500); }
  Btn ok = { 60, 256, 120, 44 };
  uiButton(ok, "확인", C_WORD);
  while (true) {
    Touch t = readTouch();
    if (ok.hit(t) || uiHitHome(t)) { sfx(SFX_CLICK); return; }
    delay(5);
  }
}

void daily() {
  int n = makePool(false);                 // 단어장 순서 그대로
  if (n == 0) { uiToast("단어가 없어요", C_BAD); return; }
  int days = (n + DAY_SIZE - 1) / DAY_SIZE;
  char key[12];
  dayKey(key);
  int done = kvGetInt(key, 0);             // 통과한 일차 수
  if (done > days) done = days;
  int view = done < days ? done : days - 1;

  const Btn PREV = { 8, 44, 40, 40 }, NEXT = { 192, 44, 40, 40 };
  const Btn LEARN = { 8, 238, 108, 38 }, TEST = { 124, 238, 108, 38 };
  const Btn REVIEW = { 8, 282, 224, 34 };
  bool redraw = true;

  while (true) {
    int cnt = dayWords(view, n);
    if (redraw) {
      redraw = false;
      char s[64];
      lcd.fillScreen(C_BG);
      snprintf(s, sizeof(s), "하루 10단어 · %s", COURSE_NAMES[course]);
      uiTopBar(s, C_WORD);
      // 일차 + 상태
      snprintf(s, sizeof(s), "%d일차", view + 1);
      uiFont(24);
      uiCenter(s, 120, 58, C_TEXT, C_BG);
      uiFont(12);
      if (view < done)       uiCenter("통과한 일차", 120, 80, C_OK, C_BG);
      else if (done >= days) uiCenter("모두 끝냈어요!", 120, 80, C_OK, C_BG);
      else                   uiCenter("오늘 공부할 차례", 120, 80, C_WARN, C_BG);
      uiButton(PREV, "◀", view > 0 ? C_LINE : C_BG, view > 0 ? C_TEXT : C_LINE);
      bool canNext = view < done && view < days - 1;
      uiButton(NEXT, "▶", canNext ? C_LINE : C_BG, canNext ? C_TEXT : C_LINE);
      // 전체 진도
      lcd.fillRoundRect(12, 92, 216, 8, 4, C_LINE);
      if (done) lcd.fillRoundRect(12, 92, max(8, 216 * done / days), 8, 4, C_OK);
      snprintf(s, sizeof(s), "진도 %d / %d일 (단어 %d개)", done, days, n);
      uiCenter(s, 120, 110, C_SUB, C_BG);
      // 오늘의 단어 미리 보기 (2줄 x 5)
      lcd.fillRoundRect(8, 120, 224, 112, 10, C_CARD);
      for (int i = 0; i < cnt; i++) {
        int x = 14 + (i % 2) * 110, y = 130 + (i / 2) * 21;
        char en[32];
        snprintf(en, sizeof(en), "%s", WORDS[dayList[i]].en);
        lcd.setFont(&fonts::FreeSans9pt7b);
        if (lcd.textWidth(en) > 104) lcd.setFont(&fonts::Font0);
        while (lcd.textWidth(en) > 104 && strlen(en) > 4) {   // 그래도 길면 줄이기
          size_t L = strlen(en);
          en[L - 3] = '.'; en[L - 2] = '.'; en[L - 1] = 0;
        }
        lcd.setTextDatum(middle_left);
        lcd.setTextColor(isWrong(dayList[i]) ? C_BAD : C_TEXT, C_CARD);
        lcd.drawString(en, x, y);
      }
      uiButton(LEARN, "1. 익히기", C_WORD);
      uiButton(TEST, "2. 테스트", C_OK);
      uiButton(REVIEW, done ? "복습 테스트 (지난 단어)" : "복습 테스트 (1일차 통과 후)", done ? C_WARN : C_LINE,
               done ? TFT_WHITE : C_SUB, 12);
    }
    Touch t = readTouch();
    if (uiHitHome(t)) return;
    if (PREV.hit(t) && view > 0) { view--; redraw = true; sfx(SFX_CLICK); }
    if (NEXT.hit(t) && view < done && view < days - 1) { view++; redraw = true; sfx(SFX_CLICK); }
    if (LEARN.hit(t)) {
      sfx(SFX_CLICK);
      char title[48];
      snprintf(title, sizeof(title), "%d일차 익히기", view + 1);
      cards(dayList, cnt, title, 0);
      redraw = true;
    }
    if (TEST.hit(t)) {
      sfx(SFX_CLICK);
      char title[48];
      snprintf(title, sizeof(title), "%d일차 테스트", view + 1);
      uiShuffle16(dayList, cnt);
      int score = quizRun(dayList, cnt, title, true);
      if (score >= 0) {
        int need = (PASS_SCORE * cnt + DAY_SIZE - 1) / DAY_SIZE;
        bool passed = score >= need;
        bool newly = passed && view == done && done < days;
        if (newly) { done++; kvSetInt(key, done); }
        dayResult(score, cnt, passed, newly, done, passed && done >= days);
        view = done < days ? done : days - 1;
      }
      redraw = true;
    }
    if (REVIEW.hit(t)) {
      if (!done) { uiToast("1일차를 통과하면 열려요", C_SUB); redraw = true; continue; }
      sfx(SFX_CLICK);
      while (true) {
        // 지난 단어 중 틀렸던 것 먼저, 나머지는 무작위
        int lim = done * DAY_SIZE < n ? done * DAY_SIZE : n;
        static uint16_t tmp[WORD_MAX];
        int wn = 0, on = 0;
        for (int i = 0; i < lim; i++) if (isWrong(pool[i])) tmp[wn++] = pool[i];
        uiShuffle16(tmp, wn);
        int qn = 0;
        for (int i = 0; i < wn && qn < DAY_SIZE; i++) dayList[qn++] = tmp[i];
        for (int i = 0; i < lim; i++) if (!isWrong(pool[i])) tmp[on++] = pool[i];
        uiShuffle16(tmp, on);
        for (int i = 0; i < on && qn < DAY_SIZE; i++) dayList[qn++] = tmp[i];
        uiShuffle16(dayList, qn);
        int score = quizRun(dayList, qn, "복습 테스트", true);
        if (score < 0 || !uiResult("복습 테스트", C_WARN, score, qn)) break;
      }
      redraw = true;
    }
    delay(5);
  }
}

}  // namespace

// ---------------------------------------------------------------------
//  영어 단어 첫 화면
// ---------------------------------------------------------------------
void appWords() {
  if (!kvGetBytes("w_wrong", wrongBits, sizeof(wrongBits))) memset(wrongBits, 0, sizeof(wrongBits));
  wrongDirty = false;
  course = kvGetInt("w_course", 1);
  hwSetSaveHook(saveWrong);                  // 절전·배터리 부족 직전에 오답 노트 저장
  if (course < 0 || course >= COURSES) course = 0;

  const int TAB_Y = TOPBAR_H;
  const Btn DAILY = { 8, 86, 224, 62 };
  const Btn B[4] = { { 8, 156, 108, 54 }, { 124, 156, 108, 54 }, { 8, 216, 108, 54 }, { 124, 216, 108, 54 } };
  bool redraw = true;
  while (true) {
    if (redraw) {
      redraw = false;
      char s[96], key[12];
      int n = makePool(false), wc = wrongCount();
      int days = (n + DAY_SIZE - 1) / DAY_SIZE;
      dayKey(key);
      int done = kvGetInt(key, 0);
      if (done > days) done = days;

      lcd.fillScreen(C_BG);
      uiTopBar("영어 단어", C_WORD);
      uiTabs(COURSE_NAMES, COURSES, course, TAB_Y, C_WORD);
      snprintf(s, sizeof(s), "단어 %d개 · 오답 %d개", n, wc);
      uiFont(12);
      uiCenter(s, 120, 74, C_SUB, C_BG);

      lcd.fillRoundRect(DAILY.x, DAILY.y, DAILY.w, DAILY.h, 12, C_WORD);
      uiFont(24);
      uiCenter("하루 10단어", 120, DAILY.y + 22, TFT_WHITE, C_WORD);
      if (done >= days) snprintf(s, sizeof(s), "%d일 모두 끝! 복습해요", days);
      else              snprintf(s, sizeof(s), "오늘은 %d일차 · 진도 %d / %d일", done + 1, done, days);
      uiFont(12);
      uiCenter(s, 120, DAILY.y + 47, TFT_WHITE, C_WORD);

      uiButton(B[0], "카드 학습", UI_RGB(52, 152, 219));
      uiButton(B[1], "뜻 맞히기", C_OK);
      uiButton(B[2], "철자 쓰기", C_WARN);
      snprintf(s, sizeof(s), "오답 노트 (%d)", wc);
      uiButton(B[3], s, C_BAD);
      uiFont(12);
      uiCenter("단어는 data_words.h 에서 바꿀 수 있어요", 120, 292, C_SUB, C_BG);
    }
    Touch t = readTouch();
    if (uiHitHome(t)) { saveWrong(); hwSetSaveHook(nullptr); return; }
    int th = uiTabHit(t, COURSES, TAB_Y);
    if (th >= 0 && th != course) {
      course = th; kvSetInt("w_course", course);
      sfx(SFX_CLICK); redraw = true;
      continue;
    }
    if (DAILY.hit(t)) { sfx(SFX_CLICK); waitRelease(); daily(); waitRelease(); redraw = true; }
    for (int i = 0; i < 4; i++) {
      if (!B[i].hit(t)) continue;
      sfx(SFX_CLICK);
      waitRelease();
      if (i == 0) {
        int n = makePool(false);
        char key[12];
        snprintf(key, sizeof(key), "w_pos%d", course);
        cards(pool, n, "카드 학습", kvGetInt(key, 0), key);
      }
      if (i == 1) while (quizMode(false)) {}
      if (i == 2) while (spelling()) {}
      if (i == 3) wrongNote();
      waitRelease();
      redraw = true;
    }
    delay(5);
  }
}
