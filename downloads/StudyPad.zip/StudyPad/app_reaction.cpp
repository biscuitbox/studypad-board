// =====================================================================
//  반응 속도 테스트  -  ★ 새 앱 만들기 예제 ★
//
//  새 앱을 만드는 순서
//   1) 이 파일을 복사해서 app_내앱.cpp 로 이름을 바꿔요.
//   2) 맨 아래 함수 이름(appReaction)을 바꿔요.  예: appMyGame
//   3) apps.h 에  void appMyGame();  한 줄 추가
//   4) StudyPad.ino 의 APPS[] 표에  { "내 게임", 색, 아이콘함수, appMyGame },  추가
//
//  앱의 기본 모양
//     화면 그리기  →  while(true) { 터치 읽기 → 처리 → ◀ 누르면 return }
// =====================================================================
#include "apps.h"

void appReaction() {
  const uint16_t C_GO = UI_RGB(46, 204, 113);
  int best = kvGetInt("react_best", 0);       // 저장된 최고 기록 (ms)

  while (true) {
    // ---- 1. 준비 화면 ----
    lcd.fillScreen(C_BG);
    uiTopBar("반응 속도", C_BAD);
    uiFont(24);
    uiCenter("화면을 톡!", 120, 140, C_TEXT, C_BG);
    uiFont(16);
    uiCenter("초록색이 되면 최대한 빨리", 120, 180, C_SUB, C_BG);
    uiCenter("화면을 누르세요", 120, 202, C_SUB, C_BG);
    char s[64];
    if (best) snprintf(s, sizeof(s), "최고 기록 %d ms", best);
    else      snprintf(s, sizeof(s), "아직 기록이 없어요");
    uiCenter(s, 120, 260, C_BAD, C_BG);

    // 톡 누를 때까지 기다리기 (◀ 누르면 앱 끝)
    while (true) {
      Touch t = readTouch();
      if (uiHitHome(t)) return;
      if (t.type == T_UP && t.tap) break;
      delay(5);
    }

    // ---- 2. 기다리기 (2~5초 사이 아무 때나) ----
    lcd.fillScreen(C_BAD);
    uiFont(24);
    uiCenter("기다려...", 120, 160, TFT_WHITE, C_BAD);
    uint32_t goTime = millis() + random(2000, 5000);
    bool early = false;
    while ((int32_t)(millis() - goTime) < 0) {
      Touch t = readTouch();
      if (t.type == T_DOWN) { early = true; break; }    // 너무 일찍 누름!
      delay(1);
    }

    // ---- 3. 결과 ----
    if (early) {
      sfx(SFX_WRONG);
      lcd.fillScreen(C_WARN);
      uiCenter("너무 빨라요!", 120, 160, TFT_WHITE, C_WARN);
    } else {
      lcd.fillScreen(C_GO);
      uiCenter("지금!", 120, 160, TFT_WHITE, C_GO);
      led(false, true, false);
      uint32_t start = millis();
      while (readTouch().type != T_DOWN) delay(1);
      int ms = millis() - start;
      led(false, false, false);
      sfx(SFX_OK);
      lcd.fillScreen(C_BG);
      snprintf(s, sizeof(s), "%d ms", ms);
      lcd.setFont(&fonts::FreeSansBold24pt7b);
      uiCenter(s, 120, 150, C_TEXT, C_BG);
      if (best == 0 || ms < best) {
        best = ms;
        kvSetInt("react_best", best);             // 최고 기록 저장
        uiFont(16);
        uiCenter("신기록!", 120, 200, C_OK, C_BG);
        sfx(SFX_WIN);
      }
    }
    waitRelease();
    uint32_t until = millis() + 1500;
    while ((int32_t)(millis() - until) < 0) { readTouch(); delay(5); }
  }
}
