// =====================================================================
//  계산기 - 사칙연산, %, 부호 바꾸기
//  (과학 시간에 밀도 = 질량 / 부피, 속력 = 거리 / 시간 계산할 때 써 보세요)
// =====================================================================
#include "apps.h"

namespace {

const char* const KEYS[20] = {
  "C", "←", "%", "/",
  "7", "8", "9", "x",
  "4", "5", "6", "-",
  "1", "2", "3", "+",
  "+/-", "0", ".", "=",
};

char   cur[16];       // 지금 입력 중인 수
double acc = 0;       // 앞에서 계산된 값
char   op = 0;        // 기다리는 연산자
bool   fresh = true;  // 다음 숫자는 새로 입력
bool   err = false;
char   expr[40];      // 위쪽 작은 글씨

// 화면에 보이는 글자 (계산할 때는 KEYS 의 글자를 씀)
const char* label(int i) {
  if (i == 3) return "÷";
  if (i == 7) return "×";
  return KEYS[i];
}
const char* opSym(char o) { return o == '/' ? "÷" : o == 'x' ? "×" : o == '-' ? "-" : "+"; }

Btn keyRect(int i) {
  Btn b = { (int16_t)(4 + (i % 4) * 59), (int16_t)(104 + (i / 4) * 43), 55, 39 };
  return b;
}

void fmt(double v, char* out, size_t n) {
  if (v != v || v > 1e15 || v < -1e15) { snprintf(out, n, "오류"); err = true; return; }
  snprintf(out, n, "%.10g", v);
  if (strcmp(out, "-0") == 0) strcpy(out, "0");
}

void drawDisplay() {
  lcd.fillRoundRect(4, 38, 232, 60, 10, UI_RGB(30, 40, 52));
  lcd.setTextDatum(middle_right);
  uiFont(12);
  lcd.setTextColor(UI_RGB(150, 160, 175), UI_RGB(30, 40, 52));
  lcd.drawString(expr, 226, 52);
  lcd.setFont(&fonts::FreeSansBold18pt7b);
  if (lcd.textWidth(cur) > 220) lcd.setFont(&fonts::FreeSansBold12pt7b);
  if ((uint8_t)cur[0] >= 0x80) uiFont(24);       // '오류' 같은 한글
  lcd.setTextColor(TFT_WHITE, UI_RGB(30, 40, 52));
  lcd.drawString(cur, 226, 78);
}

void drawKeys() {
  for (int i = 0; i < 20; i++) {
    Btn b = keyRect(i);
    const char* k = label(i);
    uint16_t bg = C_CARD, fg = C_TEXT;
    if (i % 4 == 3) { bg = C_RAND; fg = TFT_WHITE; }
    if (i < 3)      { bg = UI_RGB(205, 210, 220); }
    if (i == 19)    { bg = C_OK; fg = TFT_WHITE; }
    lcd.fillRoundRect(b.x, b.y, b.w, b.h, 8, bg);
    if ((uint8_t)k[0] >= 0x80) uiFont(24); else lcd.setFont(&fonts::FreeSansBold12pt7b);
    uiCenter(k, b.x + b.w / 2, b.y + b.h / 2, fg, bg);
  }
}

double apply(double a, char o, double b) {
  switch (o) {
    case '+': return a + b;
    case '-': return a - b;
    case 'x': return a * b;
    case '/': if (b == 0) { err = true; return 0; } return a / b;
  }
  return b;
}

void clearAll() { strcpy(cur, "0"); acc = 0; op = 0; fresh = true; err = false; expr[0] = 0; }

void press(int i) {
  const char* k = KEYS[i];
  if (err && i != 0) clearAll();
  if (i == 0) { clearAll(); return; }
  if (i == 1) {                                   // 지우기
    if (fresh) return;
    int n = strlen(cur);
    if (n <= 1 || (n == 2 && cur[0] == '-')) { strcpy(cur, "0"); fresh = true; }
    else cur[n - 1] = 0;
    return;
  }
  if (k[0] >= '0' && k[0] <= '9') {
    if (fresh) { strcpy(cur, k); fresh = false; return; }
    if (strcmp(cur, "0") == 0) { strcpy(cur, k); return; }
    if (strlen(cur) < 12) strcat(cur, k);
    return;
  }
  if (i == 18) {                                  // 소수점
    if (fresh) { strcpy(cur, "0."); fresh = false; return; }
    if (!strchr(cur, '.') && strlen(cur) < 12) strcat(cur, ".");
    return;
  }
  if (i == 16) {                                  // 부호
    if (strcmp(cur, "0") == 0) return;
    if (cur[0] == '-') memmove(cur, cur + 1, strlen(cur));
    else { memmove(cur + 1, cur, strlen(cur) + 1); cur[0] = '-'; }
    return;
  }
  if (i == 2) {                                   // 퍼센트
    double v = atof(cur);
    v = op ? acc * v / 100 : v / 100;
    fmt(v, cur, sizeof(cur)); fresh = true;
    return;
  }
  double v = atof(cur);
  char nop = (i == 19) ? 0 : k[0];
  char a[16], b[16];
  if (op && !(fresh && nop)) {
    fmt(acc, a, sizeof(a)); fmt(v, b, sizeof(b));
    acc = apply(acc, op, v);
    if (err) { strcpy(cur, "오류"); expr[0] = 0; op = 0; fresh = true; return; }
    if (nop == 0) snprintf(expr, sizeof(expr), "%s %s %s =", a, opSym(op), b);
  } else if (!op) {
    acc = v;
  }
  op = nop;
  fmt(acc, cur, sizeof(cur));
  if (op) { snprintf(expr, sizeof(expr), "%s %s", cur, opSym(op)); }
  fresh = true;
}

}  // namespace

void appCalc() {
  clearAll();
  lcd.fillScreen(C_BG);
  uiTopBar("계산기", C_CALC);
  drawDisplay();
  drawKeys();
  while (true) {
    Touch t = readTouch();
    if (uiHitHome(t)) return;
    for (int i = 0; i < 20; i++) {
      if (keyRect(i).hit(t)) { sfx(SFX_TICK); press(i); drawDisplay(); }
    }
    delay(5);
  }
}
