// =====================================================================
//  지뢰찾기
//   - 톡 누르기 : 칸 열기          - 꾹 누르기 : 깃발 꽂기/빼기
//   - 오른쪽 위 깃발 버튼을 켜면 '톡 = 깃발' 로 바뀌어요
//   - 숫자 칸을 톡 : 주변 깃발 수가 숫자와 같으면 나머지 칸을 한 번에 열기
// =====================================================================
#include "apps.h"

namespace {

struct Level { const char* name; uint8_t cols, rows, cell, mines; };
const Level LEVELS[3] = {
  { "쉬움",   10, 12, 24, 14 },
  { "보통",   10, 12, 24, 22 },
  { "어려움", 12, 14, 20, 35 },
};

const uint8_t MINE = 0x80, OPEN = 0x40, FLAG = 0x20, CNT = 0x0F;
enum State { READY, PLAYING, WON, LOST };

uint8_t board[12 * 14];
int level, cols, rows, cell, mines, total, gx0, gy0;
State state;
int flags, opened, exploded;
uint32_t startMs;
int shownSec;
bool flagMode;

const uint16_t C_RAISED = UI_RGB(196, 202, 214);
const uint16_t C_HI     = UI_RGB(240, 243, 248);
const uint16_t C_SH     = UI_RGB(126, 134, 150);
const uint16_t C_OPENED = UI_RGB(232, 235, 240);
const uint16_t C_GRID   = UI_RGB(200, 205, 214);
const uint16_t NUMC[9] = { 0, UI_RGB(30, 90, 220), UI_RGB(20, 140, 50), UI_RGB(220, 40, 40), UI_RGB(30, 30, 140),
                           UI_RGB(140, 30, 30), UI_RGB(0, 130, 140), UI_RGB(20, 20, 20), UI_RGB(120, 120, 120) };

const Btn B_FACE = { 104, 2, 32, 28 };
const Btn B_FLAG = { 196, 2, 40, 28 };

int cellAt(int x, int y) {
  if (x < gx0 || y < gy0) return -1;
  int c = (x - gx0) / cell, r = (y - gy0) / cell;
  if (c >= cols || r >= rows) return -1;
  return r * cols + c;
}

void drawFlagIcon(int x, int y, int s) {          // (x,y) = 칸 왼쪽 위, s = 칸 크기
  int px = x + s / 2 - 1;
  lcd.fillRect(px, y + s / 5, 2, s * 3 / 5, TFT_BLACK);
  lcd.fillTriangle(px + 1, y + s / 5, px + 1, y + s / 2, px - s / 3, y + s / 3 + 1, TFT_RED);
  lcd.fillRect(px - s / 5, y + s * 4 / 5 - 1, s * 2 / 5 + 2, 2, TFT_BLACK);
}

void drawMineIcon(int x, int y, int s) {
  int cx = x + s / 2, cy = y + s / 2, r = s / 4;
  lcd.drawFastHLine(cx - r - 3, cy, 2 * r + 7, TFT_BLACK);
  lcd.drawFastVLine(cx, cy - r - 3, 2 * r + 7, TFT_BLACK);
  lcd.drawLine(cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1, TFT_BLACK);
  lcd.drawLine(cx - r - 1, cy + r + 1, cx + r + 1, cy - r - 1, TFT_BLACK);
  lcd.fillCircle(cx, cy, r, TFT_BLACK);
  lcd.fillRect(cx - r / 2, cy - r / 2, 2, 2, TFT_WHITE);
}

void drawCell(int i) {
  int x = gx0 + (i % cols) * cell, y = gy0 + (i / cols) * cell;
  uint8_t v = board[i];
  if (!(v & OPEN)) {
    bool showMine = (state == LOST) && (v & MINE) && !(v & FLAG);
    bool wrongFlag = (state == LOST) && (v & FLAG) && !(v & MINE);
    if (showMine || wrongFlag) {
      lcd.fillRect(x, y, cell, cell, C_OPENED);
      lcd.drawFastHLine(x, y + cell - 1, cell, C_GRID);
      lcd.drawFastVLine(x + cell - 1, y, cell, C_GRID);
      drawMineIcon(x, y, cell);
      if (wrongFlag) {   // 틀린 깃발: 지뢰 위에 빨간 X
        uiThickLine(lcd, x + 4, y + 4, x + cell - 5, y + cell - 5, 1, TFT_RED);
        uiThickLine(lcd, x + 4, y + cell - 5, x + cell - 5, y + 4, 1, TFT_RED);
      }
      return;
    }
    lcd.fillRect(x, y, cell, cell, C_RAISED);
    lcd.fillRect(x, y, cell, 2, C_HI);
    lcd.fillRect(x, y, 2, cell, C_HI);
    lcd.fillRect(x, y + cell - 2, cell, 2, C_SH);
    lcd.fillRect(x + cell - 2, y, 2, cell, C_SH);
    if (v & FLAG) drawFlagIcon(x, y, cell);
    return;
  }
  bool boom = (i == exploded);
  lcd.fillRect(x, y, cell, cell, boom ? TFT_RED : C_OPENED);
  lcd.drawFastHLine(x, y + cell - 1, cell, C_GRID);
  lcd.drawFastVLine(x + cell - 1, y, cell, C_GRID);
  if (v & MINE) { drawMineIcon(x, y, cell); return; }
  int n = v & CNT;
  if (n) {
    lcd.setFont(cell >= 24 ? &fonts::FreeSansBold12pt7b : &fonts::FreeSansBold9pt7b);
    lcd.setTextDatum(middle_center);
    lcd.setTextColor(NUMC[n]);
    char s[2] = { (char)('0' + n), 0 };
    lcd.drawString(s, x + cell / 2, y + cell / 2 + 1);
  }
}

void drawFace() {
  int cx = B_FACE.x + B_FACE.w / 2, cy = B_FACE.y + B_FACE.h / 2;
  lcd.fillRoundRect(B_FACE.x, B_FACE.y, B_FACE.w, B_FACE.h, 6, C_MINE);
  lcd.fillCircle(cx, cy, 12, UI_RGB(255, 214, 40));
  lcd.drawCircle(cx, cy, 12, TFT_BLACK);
  if (state == LOST) {
    lcd.drawLine(cx - 7, cy - 6, cx - 3, cy - 2, TFT_BLACK); lcd.drawLine(cx - 7, cy - 2, cx - 3, cy - 6, TFT_BLACK);
    lcd.drawLine(cx + 3, cy - 6, cx + 7, cy - 2, TFT_BLACK); lcd.drawLine(cx + 3, cy - 2, cx + 7, cy - 6, TFT_BLACK);
    lcd.drawArc(cx, cy + 9, 6, 5, 200, 340, TFT_BLACK);
  } else if (state == WON) {
    lcd.fillRect(cx - 9, cy - 5, 8, 4, TFT_BLACK); lcd.fillRect(cx + 1, cy - 5, 8, 4, TFT_BLACK);
    lcd.drawFastHLine(cx - 10, cy - 5, 20, TFT_BLACK);
    lcd.drawArc(cx, cy + 1, 6, 5, 20, 160, TFT_BLACK);
  } else {
    lcd.fillCircle(cx - 4, cy - 3, 2, TFT_BLACK); lcd.fillCircle(cx + 4, cy - 3, 2, TFT_BLACK);
    lcd.drawArc(cx, cy + 1, 6, 5, 20, 160, TFT_BLACK);
  }
}

void drawCounters() {
  char s[64];
  lcd.setFont(&fonts::Font4);
  lcd.setTextDatum(middle_left);
  // 남은 지뢰 수
  lcd.fillRect(44, 2, 56, 28, C_MINE);
  drawMineIcon(42, 4, 24);
  lcd.setTextColor(TFT_WHITE, C_MINE);
  snprintf(s, sizeof(s), "%d", mines - flags);
  lcd.drawString(s, 66, 17);
  // 시간
  int sec = (state == READY) ? 0 : shownSec;
  lcd.fillRect(140, 2, 54, 28, C_MINE);
  snprintf(s, sizeof(s), "%d", sec > 999 ? 999 : sec);
  lcd.setTextDatum(middle_right);
  lcd.drawString(s, 190, 17);
}

void drawFlagBtn() {
  uint16_t bg = flagMode ? UI_RGB(255, 214, 40) : UI_RGB(120, 132, 154);
  lcd.fillRoundRect(B_FLAG.x, B_FLAG.y, B_FLAG.w, B_FLAG.h, 6, bg);
  drawFlagIcon(B_FLAG.x + 8, B_FLAG.y + 2, 24);
}

void drawTop() {
  lcd.fillRect(0, 0, SCREEN_W, TOPBAR_H, C_MINE);
  lcd.fillRoundRect(4, 4, 34, 24, 6, TFT_WHITE);
  lcd.fillTriangle(13, 16, 25, 9, 25, 23, C_MINE);
  drawCounters();
  drawFace();
  drawFlagBtn();
}

void drawBoard() {
  lcd.fillRect(0, TOPBAR_H, SCREEN_W, SCREEN_H - TOPBAR_H, C_BG);
  for (int i = 0; i < total; i++) drawCell(i);
}

void newGame() {
  const Level& L = LEVELS[level];
  cols = L.cols; rows = L.rows; cell = L.cell; mines = L.mines;
  total = cols * rows;
  gx0 = (SCREEN_W - cols * cell) / 2;
  gy0 = TOPBAR_H + (SCREEN_H - TOPBAR_H - rows * cell) / 2;
  memset(board, 0, sizeof(board));
  state = READY; flags = 0; opened = 0; exploded = -1; shownSec = 0;
  drawTop();
  drawBoard();
}

// 첫 칸(safe) 주변 3x3 에는 지뢰를 놓지 않음
void placeMines(int safe) {
  int sc = safe % cols, sr = safe / cols, placed = 0;
  while (placed < mines) {
    int i = random(total);
    int c = i % cols, r = i / cols;
    if (abs(c - sc) <= 1 && abs(r - sr) <= 1) continue;
    if (board[i] & MINE) continue;
    board[i] |= MINE; placed++;
  }
  for (int i = 0; i < total; i++) {
    int c = i % cols, r = i / cols, n = 0;
    for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) {
      int nr = r + dr, nc = c + dc;
      if ((dr || dc) && nr >= 0 && nr < rows && nc >= 0 && nc < cols && (board[nr * cols + nc] & MINE)) n++;
    }
    board[i] = (board[i] & ~CNT) | n;
  }
}

void lose(int i) {
  state = LOST; exploded = i;
  board[i] |= OPEN;
  for (int k = 0; k < total; k++) drawCell(k);
  drawFace();
  sfx(SFX_LOSE);
  ledFlash(true, false, false, 1500);
}

void win() {
  state = WON;
  for (int k = 0; k < total; k++)
    if ((board[k] & MINE) && !(board[k] & FLAG)) { board[k] |= FLAG; drawCell(k); }
  flags = mines;
  drawCounters();
  drawFace();
  sfx(SFX_WIN);
  ledFlash(false, true, false, 2000);
  char key[10];
  snprintf(key, sizeof(key), "ms_best%d", level);
  int best = kvGetInt(key, 0);
  if (best == 0 || shownSec < best) {
    kvSetInt(key, shownSec);
    char msg[40];
    snprintf(msg, sizeof(msg), "신기록! %d초", shownSec);
    uiToast(msg, C_OK, 1500);
    drawBoard();
  }
}

// 빈 칸이면 주변까지 쭉 열기 (스택 사용)
void openCell(int start) {
  static uint8_t stack[12 * 14];
  int sp = 0;
  stack[sp++] = start;
  while (sp) {
    int i = stack[--sp];
    if (board[i] & (OPEN | FLAG)) continue;
    board[i] |= OPEN; opened++;
    drawCell(i);
    if ((board[i] & CNT) == 0) {
      int c = i % cols, r = i / cols;
      for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) {
        int nr = r + dr, nc = c + dc;
        if ((dr || dc) && nr >= 0 && nr < rows && nc >= 0 && nc < cols) {
          int j = nr * cols + nc;
          if (!(board[j] & (OPEN | FLAG)) && sp < (int)sizeof(stack)) stack[sp++] = j;
        }
      }
    }
  }
}

void doOpen(int i) {
  if (state == WON || state == LOST) return;
  if (state == READY) {
    placeMines(i);
    state = PLAYING; startMs = millis();
  }
  uint8_t v = board[i];
  if (v & FLAG) return;
  if (v & OPEN) {
    // 숫자 칸: 주변 깃발 수가 같으면 나머지 열기 (코딩)
    int n = v & CNT, f = 0;
    if (!n) return;
    int c = i % cols, r = i / cols;
    for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) {
      int nr = r + dr, nc = c + dc;
      if ((dr || dc) && nr >= 0 && nr < rows && nc >= 0 && nc < cols && (board[nr * cols + nc] & FLAG)) f++;
    }
    if (f != n) return;
    for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) {
      int nr = r + dr, nc = c + dc;
      if (!(dr || dc) || nr < 0 || nr >= rows || nc < 0 || nc >= cols) continue;
      int j = nr * cols + nc;
      if (board[j] & (OPEN | FLAG)) continue;
      if (board[j] & MINE) { lose(j); return; }
      openCell(j);
    }
  } else {
    if (v & MINE) { lose(i); return; }
    openCell(i);
    sfx(SFX_CLICK);
  }
  if (opened == total - mines) win();
}

void doFlag(int i) {
  if (state == WON || state == LOST) return;
  if (board[i] & OPEN) { doOpen(i); return; }   // 열린 숫자 칸은 깃발 모드에서도 한 번에 열기
  board[i] ^= FLAG;
  flags += (board[i] & FLAG) ? 1 : -1;
  drawCell(i);
  drawCounters();
  sfx(SFX_FLAG);
}

// 난이도 고르기 화면. -1 이면 홈으로
int chooseLevel() {
  lcd.fillScreen(C_BG);
  uiTopBar("지뢰찾기", C_MINE);
  uiFont(16);
  uiCenter("난이도를 골라요", 120, 60, C_TEXT, C_BG);
  Btn b[3];
  for (int i = 0; i < 3; i++) {
    b[i] = { 30, (int16_t)(78 + i * 66), 180, 44 };
    uiButton(b[i], LEVELS[i].name, i == 0 ? C_OK : (i == 1 ? C_WARN : C_BAD));
    char s[40], key[10];
    snprintf(key, sizeof(key), "ms_best%d", i);
    int best = kvGetInt(key, 0);
    if (best) snprintf(s, sizeof(s), "%dx%d 지뢰%d · 최고 %d초", LEVELS[i].cols, LEVELS[i].rows, LEVELS[i].mines, best);
    else      snprintf(s, sizeof(s), "%dx%d 지뢰%d · 기록 없음", LEVELS[i].cols, LEVELS[i].rows, LEVELS[i].mines);
    uiFont(12);
    uiCenter(s, 120, b[i].y + b[i].h + 11, C_SUB, C_BG);
  }
  uiFont(12);
  uiWrap("톡 = 열기   꾹 = 깃발\n숫자 칸 톡 = 주변 한 번에 열기", 10, 282, 220, 16, C_SUB, C_BG, true);
  while (true) {
    Touch t = readTouch();
    if (uiHitHome(t)) return -1;
    for (int i = 0; i < 3; i++) if (b[i].hit(t)) { sfx(SFX_CLICK); return i; }
    delay(5);
  }
}

}  // namespace

void appMinesweeper() {
  while (true) {
    level = chooseLevel();
    if (level < 0) return;
    flagMode = false;
    newGame();
    waitRelease();
    bool back = false;
    while (!back) {
      Touch t = readTouch();
      if (uiHitHome(t)) { back = true; break; }
      if (B_FACE.hit(t)) { sfx(SFX_CLICK); newGame(); continue; }
      if (B_FLAG.hit(t)) { flagMode = !flagMode; drawFlagBtn(); sfx(SFX_CLICK); continue; }

      if (t.type == T_LONG) {
        int i = cellAt(t.x, t.y);
        if (i >= 0) { if (flagMode) doOpen(i); else doFlag(i); }
      } else if (t.type == T_UP && t.tap) {
        int i = cellAt(t.x, t.y);
        if (i >= 0) { if (flagMode) doFlag(i); else doOpen(i); }
      }

      if (state == PLAYING) {
        int sec = (millis() - startMs) / 1000;
        if (sec != shownSec) { shownSec = sec; drawCounters(); }
      }
      delay(5);
    }
  }
}
